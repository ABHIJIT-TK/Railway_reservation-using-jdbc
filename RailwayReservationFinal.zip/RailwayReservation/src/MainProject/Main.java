/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MainProject;
import Metrotrain.Metro;
import Metrotrain.MetroDAO;
import RailwayReservation.Reservation;
import RailwayReservation.ReservationDAO;
import TrainDetails.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import UserDetails.*;
import java.time.*;

/**
 *
 * @author abhij
 */
public class Main {
    public static void main(String []args)throws IOException{
        
        BufferedReader sc=new BufferedReader(new InputStreamReader(System.in));
        do{
        System.out.println("Welcome Passenger");
        System.out.println("1.Login \n2.SignUp\n3.Admin\n4.Exit");
        System.out.println("Enter Your Choice: ");
        int choice=Integer.parseInt(sc.readLine());
           
        if(choice==1){
            if(login()){
                System.out.println("Logined Successfully");
                mode();
            }
            else{
                System.out.println("Invalid Password");
            }
        }
        else if(choice==2){
            if(signup()){
                System.out.println("Account Created Successfully");
                if(login()){
                    System.out.println("Logined Successfully");
                    mode();
                }
                else{
                    System.out.println("Invalid Password");
                }
                
            }
        }
        else if(choice==3){
        System.out.println("Enter Your Username : ");
        String username=sc.readLine();
        System.out.println("Enter Your Password : ");
        String password=sc.readLine();
        if(username.equals("Admin") && password.equals("admin123")){
            
            System.out.println("Enter Your choice to add ");
            System.out.println("1"+"\t\t"+"Metro details");
            System.out.println("2"+"\t\t"+"Train details");
            
            int c=Integer.parseInt(sc.readLine());
            if(c==2){
                traindetails();
            }
            else if(c==1){
                metrodetails();
            }
                    
        }
        }
        else if(choice==4) break;
        else{
            System.out.println("Invalid Choice");
        }
        }while(true);
    }
    
    public static void metrodetails() throws IOException{
        //train updation 
            MetroDAO metro=new MetroDAO();
            Metro details=new Metro();
            BufferedReader sc=new BufferedReader(new InputStreamReader(System.in));
            System.out.println("Enter Metro No : ");
            String number=sc.readLine();
            details.setMetroid(number);
            System.out.println("Enter Metro Name : ");
            String name=sc.readLine();
            details.setMetroname(name);
            System.out.println("Enter Start Place : ");
            String start=sc.readLine();
            details.setStartingfrom(start);
            System.out.println("Enter Destination Place : ");
            String end=sc.readLine();
            details.setEndingto(end);
            System.out.println("Enter Price of each Seat : ");
            String price=sc.readLine();
            details.setMetro_price(price);
            
            if(metro.addMetroDetail(details)==1){
                System.out.println(name+" Metro is Added Successfully");
            }
            else{
                System.out.println("Record Failed");
            }
    }
    
    public static void traindetails() throws IOException{
        //train updation 
            TrainDAO train=new TrainDAO();
            BufferedReader sc=new BufferedReader(new InputStreamReader(System.in));
            System.out.println("Enter Train No : ");
            int number=Integer.parseInt(sc.readLine());
            train.setNo(number);
            System.out.println("Enter Train Name : ");
            String name=sc.readLine();
            train.setName(name);
            System.out.println("Enter Start Place : ");
            String start=sc.readLine();
            train.setStart(start);
            System.out.println("Enter Destination Place : ");
            String end=sc.readLine();
            train.setDestination(end);
            System.out.println("Enter Price of each Seat : ");
            int price=Integer.parseInt(sc.readLine());
            train.setPrice(price);
            
            if(train.addTrainDetail()==1){
                System.out.println(name+" Train is Added Successfully");
            }
            else{
                System.out.println("Record Failed");
            }
    }
    
    
    public static void mode() throws IOException{
        System.out.println("choice"+"\t\t"+"Mode");
	System.out.println("1"+"\t\t"+"Metro");
	System.out.println("2"+"\t\t"+"Train Reservation");
	System.out.println("3"+"\t\t"+"platform Ticket");
	System.out.println("4"+"\t\t"+"Payment");
        BufferedReader sc=new BufferedReader(new InputStreamReader(System.in));
        int choice=Integer.parseInt(sc.readLine());
        switch(choice)
	{
	case 1:
		metro();
		break;
	case 2:
            reservation();
	    break;
	
        case 3:
            platformTicket();
            break;
        }
    }
    
    
    
    public static void platformTicket() throws IOException{
        BufferedReader sc=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter number of tickets : ");
        int ticket=Integer.parseInt(sc.readLine());
        int total=ticket*10;
        int id=(int)(Math.random()*1000);
        System.out.println("\tTicket id = "+id);
        System.out.println("\tNo of Ticket = "+ticket);
        String date=LocalDate.now().toString();
        System.out.println("\tDate = "+date);
        System.out.println("\tTotal Price = "+total);
        System.out.println("Proceed to pay \nEnter y for yes or n for n");
        char c=sc.readLine().charAt(0);
        if(c=='y'){
            ReservationDAO reg=new ReservationDAO();
            if(reg.setPlatformTicket(String.valueOf(id),date,String.valueOf(ticket),String.valueOf(total))==1){
                System.out.println("Payment Success");
            }
            else{
                System.out.println("Payment Failed");
            }
        }
    }
    
    public static void reservation() throws IOException{
        BufferedReader sc=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter your Start place : ");
        String startPlace = sc.readLine();
        System.out.println("Enter your Destination place : ");
        String endPlace = sc.readLine();
        ReservationDAO reg=new ReservationDAO();
        Reservation person=reg.search(startPlace,endPlace);
        if(person.getTrainNo()!=null){
            System.out.println("Your Train Number : "+person.getTrainNo());
            System.out.println("Your Train Name : "+person.getTrainName());
            System.out.println("Your Ticket Price for Each Member : "+person.getPrice());
            System.out.println("Enter No of tickets : ");
            int ticket=Integer.parseInt(sc.readLine());
            int total=Integer.parseInt(person.getPrice())*ticket;
            System.out.println("Your Total Amount : "+total);
            System.out.println("Proceed to Pay \nEnter y for Yes and n for No");
            char c=sc.readLine().charAt(0);
            if(c=='y'){
                Reservation p1=new Reservation();
                p1.setPassengerNo(String.valueOf(ticket));
                p1.setStartingPlace(startPlace);
                p1.setDestinationPlace(endPlace);
                p1.setTrainNo(person.getTrainNo());
                p1.setTrainName(person.getTrainName());
                p1.setPrice(person.getPrice());
                String date=LocalDate.now().toString();
                p1.setDate(date);
                p1.setTickets(String.valueOf(ticket));
                p1.setTotal(String.valueOf(total));
                if(reg.setReserve(p1)==1){
                    System.out.println("Payment Successfully");
                }
                else{
                    System.out.println("Failed to reserve ur ticket");
                }
            }
        }
        else{
            System.out.println("Train not Avialable");
        }
    }
    
    
    public static void metro() throws IOException{
        BufferedReader sc=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter your Start place : ");
        String startPlace = sc.readLine();
        System.out.println("Enter your Destination place : ");
        String endPlace = sc.readLine();
        MetroDAO reg=new MetroDAO();
        Metro person=reg.search(startPlace,endPlace);
        if(person.getMetroid()!=null){
            System.out.println("Your Metro Number : "+person.getMetroid());
            System.out.println("Your Metro Name : "+person.getMetroname());
            System.out.println("Your Ticket Price for Each Member : "+person.getMetro_price());
            System.out.println("Enter No of tickets : ");
            int ticket=Integer.parseInt(sc.readLine());
            int total=Integer.parseInt(person.getMetro_price())*ticket;
            System.out.println("Your Total Amount : "+total);
            System.out.println("Proceed to Pay \nEnter y for Yes and n for No");
            char c=sc.readLine().charAt(0);
            if(c=='y'){
                Reservation p1=new Reservation();
                p1.setPassengerNo(String.valueOf(ticket));
                p1.setStartingPlace(startPlace);
                p1.setDestinationPlace(endPlace);
                p1.setTrainNo(person.getMetroid());
                p1.setTrainName(person.getMetroname());
                p1.setPrice(person.getMetro_price());
                String date=LocalDate.now().toString();
                p1.setDate(date);
                p1.setTickets(String.valueOf(ticket));
                p1.setTotal(String.valueOf(total));
                if(reg.setReserve(p1)==1){
                    System.out.println("Payment Successfully");
                }
                else{
                    System.out.println("Failed to reserve ur ticket");
                }
            }
        }
        else{
            System.out.println("Metro not Avialable");
        }
    }
    
    public static boolean login() throws IOException {
        
        BufferedReader sc=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter Your Username : ");
        String username=sc.readLine();
        System.out.println("Enter Your Password : ");
        String password=sc.readLine();
        UserDAO db=new UserDAO();
        if(password.equals(db.getPassword(username))){
            return true;
        }
        
        return false;
    }
    
    
    
    public static boolean signup() throws IOException{
        UserDAO db=new UserDAO();
        User person=new User();
        BufferedReader sc=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter your name : ");
        String name=sc.readLine();
        person.setName(name);
        System.out.println("Enter your Email Address : ");
        String email=sc.readLine();
        person.setEmail(email);
        System.out.println("Enter your Username : ");
        String username=sc.readLine();
        person.setUsername(username);
        System.out.println("Enter your password : ");
        String password=sc.readLine();
        person.setPassword(password);
        System.out.println("Enter your Address : ");
        String address=sc.readLine();
        person.setAddress(address);
        
        int check=db.createAccount(person);
        if(check==1) return true;
        return false;
        
        
        
    }
}


