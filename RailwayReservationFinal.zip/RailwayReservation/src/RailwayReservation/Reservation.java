/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package RailwayReservation;

/**
 *
 * @author abhij
 */
public class Reservation {

    /**
     * @param args the command line arguments
     */
    private String passengerNo;
	    private String startingPlace;
	    private String destinationPlace;
	    private String trainNo;
	    private String trainName;
	    private String date;
	    private String tickets;
	    private String price;
	    private String total;

    /**
     * @return the passengerNo
     */
    public String getPassengerNo() {
        return passengerNo;
    }

    /**
     * @param passengerNo the passengerNo to set
     */
    public void setPassengerNo(String passengerNo) {
        this.passengerNo = passengerNo;
    }

    /**
     * @return the startingPlace
     */
    public String getStartingPlace() {
        return startingPlace;
    }

    /**
     * @param startingPlace the startingPlace to set
     */
    public void setStartingPlace(String startingPlace) {
        this.startingPlace = startingPlace;
    }

    /**
     * @return the destinationPlace
     */
    public String getDestinationPlace() {
        return destinationPlace;
    }

    /**
     * @param destinationPlace the destinationPlace to set
     */
    public void setDestinationPlace(String destinationPlace) {
        this.destinationPlace = destinationPlace;
    }

    /**
     * @return the trainNo
     */
    public String getTrainNo() {
        return trainNo;
    }

    /**
     * @param trainNo the trainNo to set
     */
    public void setTrainNo(String trainNo) {
        this.trainNo = trainNo;
    }

    /**
     * @return the trainName
     */
    public String getTrainName() {
        return trainName;
    }

    /**
     * @param trainName the trainName to set
     */
    public void setTrainName(String trainName) {
        this.trainName = trainName;
    }

    /**
     * @return the date
     */
    public String getDate() {
        return date;
    }

    /**
     * @param date the date to set
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     * @return the tickets
     */
    public String getTickets() {
        return tickets;
    }

    /**
     * @param tickets the tickets to set
     */
    public void setTickets(String tickets) {
        this.tickets = tickets;
    }

    /**
     * @return the price
     */
    public String getPrice() {
        return price;
    }

    /**
     * @param price the price to set
     */
    public void setPrice(String price) {
        this.price = price;
    }

    /**
     * @return the total
     */
    public String getTotal() {
        return total;
    }

    /**
     * @param total the total to set
     */
    public void setTotal(String total) {
        this.total = total;
    }
    
}
