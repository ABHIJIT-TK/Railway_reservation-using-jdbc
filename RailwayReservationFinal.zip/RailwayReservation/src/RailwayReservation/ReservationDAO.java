/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package RailwayReservation;
import java.sql.*;
import java.util.*;
/**
 *
 * @author abhij
 */
public class ReservationDAO {
	 Connection con;
	    PreparedStatement pst;
	    ResultSet rs;
	    
	    public ReservationDAO(){
	        try{
	            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/railwayreservation","root","mysql");
	        }
	        catch(SQLException e){
	            System.out.println(e);
	        }
	    }
	    
	    
	    
	    public Reservation search(String start,String end){
	        Reservation person=new Reservation();
	        try{
	            pst=con.prepareStatement("select * from Train where train_start=? and train_destination=?;");
	            pst.setString(1, start);
	            pst.setString(2,end);
	            rs=pst.executeQuery();
	            if(rs.next()){
	                person.setTrainNo(rs.getString("train_id"));
                         person.setTrainName(rs.getString("train_name"));
                        person.setPrice(rs.getString("price"));
	            }
	        }
	        catch(SQLException e){
	            e.printStackTrace();
	        }
	        return person;
	    }
	    
	    public int setReserve(Reservation person){
	        int check=0;
	        
	        try{
	            pst=con.prepareStatement("insert into reservation values(?,?,?,?,?,?,?,?);");
	            pst.setString(1, person.getPassengerNo());
	            pst.setString(2, person.getStartingPlace());
	            pst.setString(3,person.getDestinationPlace());
	            pst.setString(4, person.getTrainNo());
	            pst.setString(5, person.getTrainName());
	            pst.setString(6, person.getDate());
	            pst.setString(7,person.getTickets());
	            pst.setString(8, person.getTotal());
	            check=pst.executeUpdate();
	            
	        }
	        catch(SQLException e){
	            e.printStackTrace();
	        }
	        
	        return check;
	    }
               public int setPlatformTicket(String ...details){
                   int check=0;
                   
                   try{
	            pst=con.prepareStatement("insert into platform values(?,?,?,?);");
	            pst.setString(1, details[0]);
	            pst.setString(2, details[1]);
	            pst.setString(3,details[2]);
	            pst.setString(4, details[3]);
	            
	            check=pst.executeUpdate();
	            
	        }
	        catch(SQLException e){
	            e.printStackTrace();
	        }
	        
	        return check;
                   
               }
		
}
