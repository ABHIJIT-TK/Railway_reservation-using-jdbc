/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TrainDetails;

/**
 *
 * @author abhij
 */
public class Train {
	 private String Train_number,Train_name,start,destination,price;
    /**
     * @return the Train_number
     */
    public String getTrain_number() {
        return Train_number;
    }

    /**
     * @param Train_number the Train_number to set
     */
    public void setTrain_number(String Train_number) {
        this.Train_number = Train_number;
    }

    /**
     * @return the Train_name
     */
    public String getTrain_name() {
        return Train_name;
    }

    /**
     * @param Train_name the Train_name to set
     */
    public void setTrain_name(String Train_name) {
        this.Train_name = Train_name;
    }

    /**
     * @return the start
     */
    public String getStart() {
        return start;
    }

    /**
     * @param start the start to set
     */
    public void setStart(String start) {
        this.start = start;
    }

    /**
     * @return the destination
     */
    public String getDestination() {
        return destination;
    }

    /**
     * @param destination the destination to set
     */
    public void setDestination(String destination) {
        this.destination = destination;
    }

    /**
     * @return the price
     */
    public String getPrice() {
        return price;
    }

    /**
     * @param price the price to set
     */
    public void setPrice(String price) {
        this.price = price;
    }

}
