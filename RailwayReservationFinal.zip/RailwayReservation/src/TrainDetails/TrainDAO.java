/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TrainDetails;

/**
 *
 * @author abhij
 */
import java.sql.*;
import java.util.ArrayList;
public class TrainDAO {
    private int no,price;
    private String name,start,destination;
    
    Connection con;
    PreparedStatement pst;
    ResultSet rs;
    public TrainDAO(){
        try{
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/railwayreservation","root","mysql");
        }
        catch(SQLException e){
            System.out.println(e);
        }
    }

    public int getNo() {
        return no;
    }

 
    public void setNo(int no) {
        this.no = no;
    }

 
    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }
    
    //data Access Object
    
    public int addTrainDetail(){
        int check=0;
        try{
            pst=con.prepareStatement("Insert into train values(?,?,?,?,?);");
            pst.setString(1,String.valueOf(no));
            pst.setString(2,name);
            pst.setString(3,start);
            pst.setString(4,destination);
            pst.setString(5,String.valueOf(price));
            check=pst.executeUpdate();
        }
        catch(Exception e){
            System.out.println(e);
        }
        return check;
    }
    
    
}
