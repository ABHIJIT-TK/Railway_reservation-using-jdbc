/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Metrotrain;


public class Metro {
    private String metroname;
    private String metroid;
    private String startingfrom;
    private String endingto;	  
    private String metro_price;
   
    /**
     * @return the metroname
     */
    public String getMetroname() {
        return metroname;
    }

    /**
     * @param metroname the metroname to set
     */
    public void setMetroname(String metroname) {
        this.metroname = metroname;
    }

    /**
     * @return the metroid
     */
    public String getMetroid() {
        return metroid;
    }

    /**
     * @param metroid the metroid to set
     */
    public void setMetroid(String metroid) {
        this.metroid = metroid;
    }

    /**
     * @return the startingfrom
     */
    public String getStartingfrom() {
        return startingfrom;
    }

    /**
     * @param startingfrom the startingfrom to set
     */
    public void setStartingfrom(String startingfrom) {
        this.startingfrom = startingfrom;
    }

    /**
     * @return the endingto
     */
    public String getEndingto() {
        return endingto;
    }

    /**
     * @param endingto the endingto to set
     */
    public void setEndingto(String endingto) {
        this.endingto = endingto;
    }

    /**
     * @return the metro_date
     */
    
   

    /**
     * @return the metro_price
     */
    public String getMetro_price() {
        return metro_price;
    }

    /**
     * @param metro_price the metro_price to set
     */
    public void setMetro_price(String metro_price) {
        this.metro_price = metro_price;
    }

    
    
    
}
