/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Metrotrain;
import RailwayReservation.Reservation;
import java.sql.*;
/**
 *
 * @author abhij
 */
public class MetroDAO {
    Connection con;
    PreparedStatement pst;
    ResultSet rs;
    public MetroDAO(){
        try{
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/railwayreservation","root","mysql");
        }
        catch(SQLException e){
            System.out.println(e);
        }
    }
    
    public int addMetroDetail(Metro details){
        int check=0;
        try{
            pst=con.prepareStatement("Insert into metro values(?,?,?,?,?);");
            pst.setString(1,details.getMetroid());
            pst.setString(2,details.getMetroname());
            pst.setString(3,details.getStartingfrom());
            pst.setString(4,details.getEndingto());
            pst.setString(5,details.getMetro_price());
            check=pst.executeUpdate();
        }
        catch(Exception e){
            System.out.println(e);
        }
        return check;
    }
    
    
    public Metro search(String start,String end){
	        Metro person=new Metro();
	        try{
	            pst=con.prepareStatement("select * from metro where metro_start=? and metro_end=?;");
	            pst.setString(1, start);
	            pst.setString(2,end);
	            rs=pst.executeQuery();
	            if(rs.next()){
	                person.setMetroid(rs.getString("metro_id"));
                         person.setMetroname(rs.getString("metro_name"));
                        person.setMetro_price(rs.getString("price"));
	            }
	        }
	        catch(SQLException e){
	            e.printStackTrace();
	        }
	        return person;
    }
    
    public int setReserve(Reservation person){
	        int check=0;
	        try{
	            pst=con.prepareStatement("insert into metro_reservation values(?,?,?,?,?,?,?,?);");
	            pst.setString(1, person.getPassengerNo());
	            pst.setString(2, person.getStartingPlace());
	            pst.setString(3,person.getDestinationPlace());
	            pst.setString(4, person.getTrainNo());
	            pst.setString(5, person.getTrainName());
	            pst.setString(6, person.getDate());
	            pst.setString(7,person.getTickets());
	            pst.setString(8, person.getTotal());
	            check=pst.executeUpdate();
	        }
	        catch(SQLException e){
	            e.printStackTrace();
	        }
	        
	        return check;
    }
    
}
